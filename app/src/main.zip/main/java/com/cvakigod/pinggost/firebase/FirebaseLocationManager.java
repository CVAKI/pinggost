package com.cvakigod.pinggost.firebase;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;

import androidx.core.app.ActivityCompat;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;

/**
 * Streams this device's GPS location into Realtime Database at:
 *   /devices/{deviceId}/location  -> { lat, lng, accuracy, timestamp }
 *   /devices/{deviceId}/control/lastSeen -> server timestamp (heartbeat)
 *
 * deviceId is the device's ANDROID_ID, so the remote-control webpage knows which
 * node to read/write for a given phone. No extra Google Play Services location
 * dependency needed -- this uses the plain Android LocationManager.
 */
public class FirebaseLocationManager implements LocationListener {

    private final Context context;
    private final LocationManager locationManager;
    private final DatabaseReference deviceRef;
    private final String deviceId;

    public FirebaseLocationManager(Context context) {
        this.context = context.getApplicationContext();
        this.locationManager = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
        this.deviceId = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
        this.deviceRef = FirebaseDatabase.getInstance().getReference("devices").child(deviceId);
        // paste this into remote-control.html's DEVICE_ID field -- filter Logcat for "PingGhost" to find it
        Log.d("PingGhost", "Device ID for remote-control.html: " + deviceId);
    }

    public String getDeviceId() {
        return deviceId;
    }

    /** Call from onResume / after permission is granted. */
    public void start() {
        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            return; // caller is responsible for requesting permission first
        }

        try {
            // GPS for accuracy when available, network provider as a fallback indoors
            if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 8000L, 10f, this);
            }
            if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 8000L, 10f, this);
            }
            // push last-known immediately so the web panel isn't empty on first load
            Location last = getBestLastKnown();
            if (last != null) pushLocation(last);
        } catch (SecurityException ignored) { }
    }

    public void stop() {
        try {
            locationManager.removeUpdates(this);
        } catch (SecurityException ignored) { }
    }

    private Location getBestLastKnown() {
        Location best = null;
        try {
            for (String provider : new String[]{LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER}) {
                if (!locationManager.isProviderEnabled(provider)) continue;
                Location loc = locationManager.getLastKnownLocation(provider);
                if (loc != null && (best == null || loc.getAccuracy() < best.getAccuracy())) {
                    best = loc;
                }
            }
        } catch (SecurityException ignored) { }
        return best;
    }

    private void pushLocation(Location location) {
        Map<String, Object> update = new HashMap<>();
        update.put("lat", location.getLatitude());
        update.put("lng", location.getLongitude());
        update.put("accuracy", location.getAccuracy());
        update.put("timestamp", System.currentTimeMillis());
        deviceRef.child("location").setValue(update);
        deviceRef.child("control").child("lastSeen").setValue(System.currentTimeMillis());
    }

    @Override
    public void onLocationChanged(Location location) {
        pushLocation(location);
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) { }

    @Override
    public void onProviderEnabled(String provider) { }

    @Override
    public void onProviderDisabled(String provider) { }
}
