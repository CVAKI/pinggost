package com.cvakigod.pinggost;

import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

/**
 * Full-screen "something is wrong" sequence, triggered when all three channels
 * (alpha/beta/gamma) read high at once. Sequence:
 *   1. Screen flicker / color glitch for a few seconds
 *   2. Creepy audio cue (res/raw/creepy_sound - you supply the file, see README)
 *   3. A few random full-black "screen off" flashes (real screen-off isn't accessible
 *      to a normal app, so this fakes it convincingly with a full-black overlay + min brightness)
 *   4. App fully closes itself
 *
 * On the next launch, SplashMeltActivity checks the "last_session_anomaly" flag and
 * plays a more corrupted melt animation as a callback to what just happened.
 */
public class ScaryActivity extends AppCompatActivity {

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Random rng = new Random();
    private MediaPlayer creepyPlayer;
    private View root;
    private View blackout;
    private TextView warningText;
    private boolean sequenceRunning = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_scary);

        root = findViewById(R.id.scaryRoot);
        blackout = findViewById(R.id.blackoutView);
        warningText = findViewById(R.id.warningText);

        playCreepySound();
        startGlitchPhase();
    }

    private void playCreepySound() {
        try {
            // Add a file named creepy_sound.mp3 (or .ogg) to app/src/main/res/raw/
            // e.g. a low drone, static burst, or distorted whisper. Keep it short (5-10s) and loud.
            int resId = getResources().getIdentifier("creepy_sound", "raw", getPackageName());
            if (resId != 0) {
                creepyPlayer = MediaPlayer.create(this, resId);
                if (creepyPlayer != null) {
                    creepyPlayer.setLooping(false);
                    creepyPlayer.start();
                }
            }
        } catch (Exception ignored) {
            // if no asset is supplied yet, the visual sequence still runs fine without audio
        }
    }

    // ---- Phase 1: rapid color/text glitch, ~3.5s ----
    private void startGlitchPhase() {
        final long glitchDurationMs = 3500;
        final long start = System.currentTimeMillis();
        final int[] glitchColors = {
                Color.parseColor("#FF1744"), Color.parseColor("#000000"),
                Color.parseColor("#FFFFFF"), Color.parseColor("#00FF41"),
                Color.parseColor("#000000")
        };

        Runnable glitchTick = new Runnable() {
            @Override public void run() {
                if (!sequenceRunning) return;
                long elapsed = System.currentTimeMillis() - start;
                if (elapsed >= glitchDurationMs) {
                    root.setBackgroundColor(Color.BLACK);
                    startBlackoutPhase();
                    return;
                }
                root.setBackgroundColor(glitchColors[rng.nextInt(glitchColors.length)]);
                warningText.setTranslationX((rng.nextFloat() - 0.5f) * 40f);
                warningText.setTranslationY((rng.nextFloat() - 0.5f) * 40f);
                warningText.setVisibility(rng.nextBoolean() ? View.VISIBLE : View.INVISIBLE);
                handler.postDelayed(this, 60 + rng.nextInt(90)); // irregular flicker timing
            }
        };
        handler.post(glitchTick);
    }

    // ---- Phase 2: a few random fake "screen off" blackouts ----
    private void startBlackoutPhase() {
        setBrightness(0f); // dim as far as the app is allowed to
        int flashCount = 3 + rng.nextInt(3);
        scheduleBlackoutFlash(flashCount);
    }

    private void scheduleBlackoutFlash(final int remaining) {
        if (!sequenceRunning) return;
        if (remaining <= 0) {
            handler.postDelayed(this::closeApp, 500);
            return;
        }
        blackout.setVisibility(View.VISIBLE);
        handler.postDelayed(() -> {
            blackout.setVisibility(View.INVISIBLE);
            handler.postDelayed(() -> scheduleBlackoutFlash(remaining - 1), 200 + rng.nextInt(400));
        }, 400 + rng.nextInt(700));
    }

    private void setBrightness(float value) {
        WindowManager.LayoutParams params = getWindow().getAttributes();
        params.screenBrightness = value; // 0f = dimmest the app can force, not a true power-off
        getWindow().setAttributes(params);
    }

    // ---- Phase 3: fully close the app ----
    private void closeApp() {
        sequenceRunning = false;
        if (creepyPlayer != null) {
            try { creepyPlayer.stop(); creepyPlayer.release(); } catch (Exception ignored) { }
        }
        finishAffinity(); // closes every activity in the task, app disappears from the user's view
        // Process.killProcess ensures nothing lingers in the background so the NEXT launch
        // is a clean cold-start -> the melt animation plays properly.
        handler.postDelayed(() -> Process.killProcess(Process.myPid()), 150);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        sequenceRunning = false;
        handler.removeCallbacksAndMessages(null);
        if (creepyPlayer != null) {
            try { creepyPlayer.release(); } catch (Exception ignored) { }
        }
    }

    @Override
    public void onBackPressed() {
        // block back-button escape during the sequence for effect
    }
}
