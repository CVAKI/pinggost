package com.cvakigod.pinggost.firebase;

import android.content.Context;
import android.provider.Settings;

import androidx.annotation.NonNull;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ServerValue;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

/**
 * Marks /devices/{deviceId}/control/online = true while the app is alive, and wires an
 * onDisconnect() hook so Firebase itself flips it back to false the moment the socket drops
 * (app killed, phone loses signal, etc.) -- no heartbeat polling needed on the dashboard side.
 */
public class PresenceManager {

    private final DatabaseReference controlRef;
    private ValueEventListener connectedListener;

    public PresenceManager(Context context) {
        String deviceId = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
        this.controlRef = FirebaseDatabase.getInstance().getReference("devices").child(deviceId).child("control");
    }

    public void start() {
        DatabaseReference connectedRef = FirebaseDatabase.getInstance().getReference(".info/connected");
        connectedListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Boolean connected = snapshot.getValue(Boolean.class);
                if (Boolean.TRUE.equals(connected)) {
                    // as soon as we go offline for any reason, Firebase flips this server-side
                    controlRef.child("online").onDisconnect().setValue(false);
                    controlRef.child("lastSeen").onDisconnect().setValue(ServerValue.TIMESTAMP);

                    Map<String, Object> update = new HashMap<>();
                    update.put("online", true);
                    update.put("lastSeen", ServerValue.TIMESTAMP);
                    controlRef.updateChildren(update);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) { }
        };
        connectedRef.addValueEventListener(connectedListener);
    }

    public void stop() {
        if (connectedListener != null) {
            FirebaseDatabase.getInstance().getReference(".info/connected").removeEventListener(connectedListener);
            connectedListener = null;
        }
        controlRef.child("online").setValue(false);
    }
}
